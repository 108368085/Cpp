/*
 * CShape.cpp
 *
 *  Created on: 2021�~11��26��
 *      Author: yuyun
 */
#include "iostream"
using namespace std;
#include "CShape.h"

CShape::CShape() {
	// TODO Auto-generated constructor stub
	girth = 0;
	area = 0;
}

CShape::~CShape() {
	// TODO Auto-generated destructor stub
}


