//============================================================================
// Name        : 012.cpp
// Author      : YuYung Hsu
// Version     :
// Copyright   : Cpp Joad
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
#include "CShape.h"
#include "CCircle.h"
#include "CRectangle.h"

void doubleShape(CShape *);

int main() {
	CCircle c;
	c.setRadius(10);
	doubleShape(&c);
	cout<<c.getArea()<<endl;

	CRectangle r;
	r.setValues(10, 5);
	doubleShape(&r);
	cout<<r.getArea()<<endl;

	return 0;
}

void doubleShape(CShape * pcs){
	/*
	dynamic_cast<CCircle*>(pcs)->
			setRadius(dynamic_cast<CCircle*>(pcs)->getRadius() * 2);
			*/
	CCircle * pcc = dynamic_cast<CCircle *>(pcs);
	if(pcc != 0){
		pcc->setRadius(pcc->getRadius() * 2);
		return;
	}

	CRectangle * pcr = dynamic_cast<CRectangle *>(pcs);
	if(pcr != 0){
			pcr->setValues(pcr->getLength() * 2 , pcr->getWidth() * 2);
			return;
		}

}




