//============================================================================
// Name        : 012.cpp
// Author      : YuYung Hsu
// Version     :
// Copyright   : Cpp Joad
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
#include "CShape.h"
#include "CCircle.h"
int main() {
	CCircle cc;

	return 0;
}
